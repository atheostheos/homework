package ru.kpfu.itis;

public class Util {
    public static boolean isInArray(String str,String[] array) {
        boolean isInArray = false;
        for (int i = 0; i < array.length; i++) {
            if (array[i].equals(str)) isInArray = true;
        }
        return isInArray;
    }
}
