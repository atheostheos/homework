package ru.kpfu.itis.menu;

public class Settings {
    protected String language;
    protected String user;

    public Settings(String language, String user) {
        this.language = language;
        this.user = user;
    }
}
