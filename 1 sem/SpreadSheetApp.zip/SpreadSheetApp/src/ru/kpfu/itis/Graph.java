package ru.kpfu.itis;

public class Graph {
    protected String[][] coordinatePlane;
    protected int accuracy;

    public Graph(int accuracy) {
        coordinatePlane = new String[30][30];
        this.accuracy = accuracy;

        for (int i = 0; i < 30; i++) {
            for (int j = 0; j < 30; j++) {
                coordinatePlane[i][j] = " ";
            }
        }
    }

    public void buildGraph(Cell[] cellLine) {

    }

    public void drawGraph() {
        for (int i = 0; i < coordinatePlane.length; i++) {
            String.join("", coordinatePlane[i]);
        }
    }
}
