package ru.kpfu.itis.tabs;

public class HelpTab extends Tab {

    public HelpTab() {
        super("Help", "None");
    }

    @Override
    public void showTab() {
        System.out.print("x y - choose cell\n" +
                "+n - create new spreadsheet with size n\n" +
                "n - choose spreadsheet number n\n" +
                "Tab Name - go to chosen tab\n" +
                "An params - use method in chosen tab\n");
    }

    @Override
    public void processCommand(String command) {

    }
}
